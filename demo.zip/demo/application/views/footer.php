<footer>This is footer
</footer>
</html>