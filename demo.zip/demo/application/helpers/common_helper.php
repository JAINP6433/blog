<?php
function prd($data){
	echo "<pre>";print_r($data);die;
}